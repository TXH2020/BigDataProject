# Microservices

https://microservices.io/patterns/microservices.html

Steps to Run:

1. docker compose up -d
2. curl localhost:5001/hi
3. curl localhost:5002/hello
4. docker compose down
