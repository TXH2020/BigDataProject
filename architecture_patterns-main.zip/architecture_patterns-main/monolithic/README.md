# Monolithic

https://microservices.io/patterns/monolithic.html

Steps to Run:

1. docker compose up -d
2. curl localhost:5000/hi
3. curl localhost:5000/hello
4. docker compose down
